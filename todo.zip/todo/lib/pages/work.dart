import 'package:flutter/material.dart';

class WorkPage extends StatefulWidget{
  @override
  _AddWorkState createState() => _AddWorkState();
}

class _AddWorkState extends State<WorkPage>{
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}